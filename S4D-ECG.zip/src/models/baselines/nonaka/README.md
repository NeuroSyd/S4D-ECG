
All code adapted from codebase: https://github.com/seitalab/dnn_ecg_comparison
for the paper
```
Nonaka, Seita.
"In-depth Benchmarking of Deep Neural Network Architectures for ECG Diagnosis"
```

